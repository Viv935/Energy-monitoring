<?php

/*
 | Step 3: capture EVERY register from EVERY payload into a staging
 | table (raw_registers), tagged by siteno and payload type (A/B).
 | Nothing here is written into meter_readings yet — only confirmed,
 | correctly-mapped values should ever land there. Once parameter
 | mapping is confirmed (via SPZ or continued empirical analysis),
 | a separate promotion step will copy the right registers into
 | meter_readings under their real parameter names.
 |
 | Still no session/login check — this is a device endpoint.
*/

require __DIR__ . '/../energy_monitor/config/db.php';

$raw = file_get_contents('php://input');
parse_str($raw, $fields);

$db      = $fields['db']     ?? '';
$siteno  = $fields['siteno'] ?? '';
$dataHex = $fields['data']   ?? '';

$logLine = date('Y-m-d H:i:s')
    . " | db=" . $db
    . " | siteno=" . $siteno
    . " | data_len=" . strlen($dataHex)
    . " | data=" . $dataHex
    . "\n";
file_put_contents(__DIR__ . '/raw_capture.log', $logLine, FILE_APPEND);

if ($siteno === '' || $dataHex === '') {
    http_response_code(200);
    echo "OK (nothing to store)";
    exit;
}

// The two payload shapes seen so far, identified by their first 4 hex chars.
$prefix = substr($dataHex, 0, 4);
$payloadType = ($prefix === '0BB8') ? 'A' : (($prefix === '000D') ? 'B' : 'UNKNOWN');

$insert = $conn->prepare("
    INSERT INTO raw_registers (siteno, payload_type, register_index, value, capture_time)
    VALUES (?, ?, ?, ?, NOW())
");

$registerCount = intdiv(strlen($dataHex), 4);
for ($i = 0; $i < $registerCount; $i++) {
    $chunk = substr($dataHex, $i * 4, 4);
    $value = hexdec($chunk);
    $insert->execute([$siteno, $payloadType, $i + 1, $value]);
}

http_response_code(200);
echo "OK ({$registerCount} registers stored, type {$payloadType})";