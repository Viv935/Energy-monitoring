<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'config/db.php';

echo "Alarm Engine Started<br>";

/* ==========================
   LATEST VOLTAGE READING
========================== */

$stmt = $conn->query("
    SELECT *
    FROM meter_readings
    WHERE parameter_name='Voltage'
    ORDER BY reading_time DESC
    LIMIT 1
");

$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row)
{
    exit("No Voltage Reading Found");
}

echo "Latest Voltage = " . $row['value'] . "<br>";

/* ==========================
   OVER VOLTAGE
========================== */

if ($row['value'] > 440)
{
    echo "OV Condition Met<br>";

    $check = $conn->prepare("
        SELECT id
        FROM alarms
        WHERE alarm_message='OVER VOLTAGE'
        AND status='ACTIVE'
    ");

    $check->execute();

    if ($check->rowCount() == 0)
    {
        $insert = $conn->prepare("
            INSERT INTO alarms
            (
                site_name,
                branch_name,
                parameter_name,
                alarm_value,
                actual_value,
                alarm_message,
                severity,
                status,
                alarm_time
            )
            VALUES
            (
                ?,?,?,?,?,?,
                'CRITICAL',
                'ACTIVE',
                NOW()
            )
        ");

        $insert->execute([
            'Ahmedabad',
            'Ahmedabad',
            'Voltage',
            440,
            $row['value'],
            'OVER VOLTAGE'
        ]);

        $alarmId = $conn->lastInsertId();

        $incident = $conn->prepare("
            INSERT INTO incidents
            (
                alarm_id,
                site_name,
                alarm_type,
                severity,
                assigned_to,
                status
            )
            VALUES
            (
                ?,?,?,?,
                'Site Engineer',
                'OPEN'
            )
        ");

        $incident->execute([
            $alarmId,
            'Ahmedabad',
            'OVER VOLTAGE',
            'CRITICAL'
        ]);

        echo "OV Alarm Inserted<br>";
    }
    else
    {
        echo "Active OV Alarm Already Exists<br>";
    }
}

/* ==========================
   UNDER VOLTAGE
========================== */

if ($row['value'] < 180)
{
    echo "UNDER VOLTAGE DETECTED<br>";
}

/* ==========================
   POWER FAILURE
========================== */

if ($row['value'] <= 5)
{
    echo "POWER FAILURE<br>";

    $check = $conn->prepare("
        SELECT id
        FROM alarms
        WHERE alarm_message='POWER FAILURE'
        AND status='ACTIVE'
    ");

    $check->execute();

    if ($check->rowCount() == 0)
    {
        $insert = $conn->prepare("
            INSERT INTO alarms
            (
                site_name,
                branch_name,
                parameter_name,
                alarm_value,
                actual_value,
                alarm_message,
                severity,
                status,
                alarm_time
            )
            VALUES
            (
                ?,?,?,?,?,?,
                'CRITICAL',
                'ACTIVE',
                NOW()
            )
        ");

        $insert->execute([
            'Ahmedabad',
            'Ahmedabad',
            'Voltage',
            5,
            $row['value'],
            'POWER FAILURE'
        ]);

        echo "Power Failure Alarm Inserted<br>";
    }
}

/* ==========================
   POWER RESTORED
========================== */

if ($row['value'] > 100)
{
    $update = $conn->query("
        UPDATE alarms
        SET
            status='CLEARED',
            cleared_time=NOW()
        WHERE alarm_message='POWER FAILURE'
        AND status='ACTIVE'
    ");

    echo "POWER RESTORED<br>";
}

/* ==========================
   DG RUNNING > 4 HOURS
========================== */

/* TEST VALUE */
$runtimeMinutes = 250;

if ($runtimeMinutes >= 240)
{
    echo "DG RUNNING > 4 HOURS<br>";

    $check = $conn->prepare("
        SELECT id
        FROM alarms
        WHERE alarm_message='DG RUNNING > 4 HOURS'
        AND status='ACTIVE'
    ");

    $check->execute();

    if ($check->rowCount() == 0)
    {
        $insert = $conn->prepare("
            INSERT INTO alarms
            (
                site_name,
                branch_name,
                parameter_name,
                alarm_value,
                actual_value,
                alarm_message,
                severity,
                status,
                alarm_time
            )
            VALUES
            (
                ?,?,?,?,?,?,
                'CRITICAL',
                'ACTIVE',
                NOW()
            )
        ");

        $insert->execute([
            'Ahmedabad',
            'Ahmedabad',
            'DG Runtime',
            240,
            $runtimeMinutes,
            'DG RUNNING > 4 HOURS'
        ]);

        echo "DG Alarm Inserted<br>";
    }
    else
    {
        echo "DG Alarm Already Exists<br>";
    }
}

/* ==========================
   EMERGENCY POWER OUTAGE
========================== */

$ebAvailable = ($row['value'] > 100);

/*
Replace this later using actual DG status
*/
$dgAvailable = false;

if (!$ebAvailable && !$dgAvailable)
{
    echo "EMERGENCY POWER OUTAGE<br>";

    $check = $conn->prepare("
        SELECT id
        FROM alarms
        WHERE alarm_message='EMERGENCY POWER OUTAGE'
        AND status='ACTIVE'
    ");

    $check->execute();

    if ($check->rowCount() == 0)
    {
        $insert = $conn->prepare("
            INSERT INTO alarms
            (
                site_name,
                branch_name,
                parameter_name,
                alarm_value,
                actual_value,
                alarm_message,
                severity,
                status,
                alarm_time
            )
            VALUES
            (
                ?,?,?,?,?,?,
                'CRITICAL',
                'ACTIVE',
                NOW()
            )
        ");

        $insert->execute([
            'Ahmedabad',
            'Ahmedabad',
            'POWER',
            0,
            0,
            'EMERGENCY POWER OUTAGE'
        ]);

        echo "Emergency Alarm Inserted<br>";
    }
}

echo "<br>Alarm Engine Completed";
?>