<div class="sidebar">
 <h3 class="logo">⚡ EMS</h3>
 <a href="dashboard.php">📊 Dashboard</a>
 <a href="parameters.php">⚙ Parameters</a>
 <a href="meters.php">🔌 Meters</a>
 <a href="alarms.php">🚨 Active Alarms</a>
 <a href="alarm_history.php">📜 Alarm History</a>

 <a class="nav" data-bs-toggle="collapse" href="#reportsMenu" role="button" aria-expanded="false" aria-controls="reportsMenu">
    📄 Reports
 </a>

 <div class="collapse" id="reportsMenu">

    <div style="padding-left:20px;">

        <a href="reports.php">
            └ Overview
        </a>

        <a href="daily_report.php">
            └ Daily Report
        </a>

        <a href="monthly_report.php">
            └ Monthly Report
        </a>

        <a href="meter_report.php">
            └ Meter Report
        </a>

         <a href="eb_bill_report.php">
            └ EB Reports
        </a>

        <a href="dg_report.php">
            └ DG Reports
        </a>

        <a href="master_report.php">
            └ master_report
        </a>


    </div>

 </div>

 <a href="users.php">👤 Users</a>
 <a href="event_log.php">📝 Event Log</a>

 <a class="nav" data-bs-toggle="collapse" href="#ebBills" role="button" aria-expanded="false" aria-controls="ebBills">
    💰 EB Bills
 </a>

 <div class="collapse" id="ebBills">

    <div style="padding-left:20px;">

        <strong>BECIL</strong>

        <a href="bill_entry.php?type=BECIL&company=KAL">
            └ KAL
        </a>

        <a href="bill_entry.php?type=BECIL&company=SAFL">
            └ SAFL
        </a>

        <strong>NON BECIL</strong>

        <a href="bill_entry.php?type=NON_BECIL&company=KAL">
            └ KAL
        </a>

        <a href="bill_entry.php?type=NON_BECIL&company=SAFL">
            └ SAFL
        </a>

    </div>

 </div>

 <a class="nav" data-bs-toggle="collapse" href="#dgBills" role="button" aria-expanded="false" aria-controls="dgBills">
    ⚡ DG Bills
 </a>

 <div class="collapse" id="dgBills">

    <div style="padding-left:20px;">

        <a href="bill_entry.php?type=DG&company=KAL">
            └ KAL
        </a>

        <a href="bill_entry.php?type=DG&company=SAFL">
            └ SAFL
        </a>

    </div>

 </div>

</div>