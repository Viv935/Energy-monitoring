<?php

function is_admin()
{
    return ($_SESSION['role'] ?? '') === 'admin';
}

function user_company()
{
    return $_SESSION['company'] ?? null;
}

/*
 | Critical check: verifies the given meter_id actually belongs to the
 | logged-in user's company before any page or API file uses it.
 | Without this, a client could edit ?meter_id=2 in the URL and view
 | another company's data even if the dropdown never shows it to them.
*/
function meter_belongs_to_user(PDO $conn, $meter_id)
{
    if (is_admin()) {
        return true;
    }

    $stmt = $conn->prepare("SELECT company FROM meter_master WHERE meter_id = ?");
    $stmt->execute([$meter_id]);
    $company = $stmt->fetchColumn();

    return $company !== false && $company === user_company();
}
