<?php

session_start();

require 'config/db.php';

$msg = '';

if(isset($_POST['login']))
{
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    $stmt = $conn->prepare("
    SELECT *
    FROM users
    WHERE username=?
    AND password=?
    ");

    $stmt->execute([
        $username,
        $password
    ]);

    if($stmt->rowCount() > 0)
    {
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        $_SESSION['user']    = $user['username'];
        $_SESSION['role']    = $user['role'];
        $_SESSION['company'] = $user['company']; // NULL for admin = sees everything

        header("Location: dashboard.php");
        exit;
    }
    else
    {
        $msg='Invalid Login';
    }
}

?>

<!DOCTYPE html>
<html>

<head>

<meta charset="utf-8">

<link rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

</head>

<body>

<div class="container mt-5">

<div class="row justify-content-center">

<div class="col-md-4">

<div class="card shadow">

<div class="card-body">

<h3>⚡ EMS Login</h3>

<p class="text-danger">
<?= $msg ?>
</p>

<form method="post">

<input
type="text"
name="username"
class="form-control mb-3"
placeholder="Username">

<input
type="password"
name="password"
class="form-control mb-3"
placeholder="Password">

<button
name="login"
class="btn btn-primary w-100">

Login

</button>

</form>

</div>

</div>

</div>

</div>

</div>

</body>
</html>