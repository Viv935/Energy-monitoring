<?php

session_start();

if(!isset($_SESSION['user']))
{
    header("Location: login.php");
    exit;
}

require 'config/db.php';

$type = $_GET['type'] ?? '';
$company = $_GET['company'] ?? '';

if(isset($_POST['save']))
{
    $stmt = $conn->prepare("
    INSERT INTO bills
    (
        bill_type,
        company,
        state_name,
        branch_name,
        broadcaster,
        bill_month,
        eb_units,
        common_units,
        amount,
        transmitter,
        remarks
    )
    VALUES
    (
        ?,?,?,?,?,?,?,?,?,?,?
    )
    ");

    $stmt->execute([
        $type,
        $company,
        $_POST['state_name'],
        $_POST['branch_name'],
        $_POST['broadcaster'],
        $_POST['bill_month'],
        $_POST['eb_units'],
        $_POST['common_units'],
        $_POST['amount'],
        $_POST['transmitter'],
        $_POST['remarks']
    ]);

    echo "<div class='alert alert-success'>
            Bill Saved Successfully
          </div>";
}

include 'includes/header.php';
include 'includes/sidebar.php';

?>

<div class="content">

<h3>

<?= $type ?> - <?= $company ?>

</h3>

<form method="post">

    <div class="mb-2">
        State
        <input type="text"
               name="state_name"
               class="form-control">
    </div>

    <div class="mb-2">
        Branch
        <input type="text"
               name="branch_name"
               class="form-control">
    </div>

    <div class="mb-2">
        Broadcaster
        <input type="text"
               name="broadcaster"
               class="form-control">
    </div>

    <div class="mb-2">
        Bill Month
        <input type="month"
               name="bill_month"
               class="form-control">
    </div>

    <div class="mb-2">
        EB Units
        <input type="number"
               step="0.01"
               name="eb_units"
               class="form-control">
    </div>

    <div class="mb-2">
        Common Units
        <input type="number"
               step="0.01"
               name="common_units"
               class="form-control">
    </div>

    <div class="mb-2">
        Cost
        <input type="number"
               step="0.01"
               name="amount"
               class="form-control">
    </div>

    <div class="mb-2">
        Transmitter
        <input type="text"
               name="transmitter"
               class="form-control">
    </div>

    <div class="mb-2">
        Remarks
        <textarea name="remarks"
                  class="form-control"></textarea>
    </div>

    <button type="submit"
            name="save"
            class="btn btn-primary">

        Save Bill

    </button>

</form>

</div>

<?php include 'includes/footer.php'; ?>