<?php

require '../config/db.php';

$data = [];

foreach(['Ir','Iy','Ib'] as $param)
{
    $stmt = $conn->prepare("
        SELECT value
        FROM meter_readings
        WHERE parameter_name = ?
        ORDER BY id DESC
        LIMIT 5
    ");

    $stmt->execute([$param]);

    $data[$param] =
    array_reverse(
        $stmt->fetchAll(PDO::FETCH_COLUMN)
    );
}

echo json_encode($data);

?>