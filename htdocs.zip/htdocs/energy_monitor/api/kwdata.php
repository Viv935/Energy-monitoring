<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require '../config/db.php';

$stmt = $conn->query("
SELECT
    id,
    value
FROM meter_readings
WHERE parameter_name='KW-Tot.'
ORDER BY id ASC
LIMIT 10
");

$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');

echo json_encode($data);

exit;