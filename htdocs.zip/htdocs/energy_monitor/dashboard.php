<?php

session_start();

if(!isset($_SESSION['user']))
{
    header("Location: login.php");
    exit;
}

require 'config/db.php';
require 'includes/auth_helpers.php';

function getLatestValue($conn, $parameter)
{
    $stmt = $conn->prepare("
        SELECT value
        FROM meter_readings
        WHERE parameter_name = ?
        ORDER BY reading_time DESC
        LIMIT 1
    ");

    $stmt->execute([$parameter]);

    return $stmt->fetchColumn();
}

$vr = getLatestValue($conn, 'Vr');
$vy = getLatestValue($conn, 'Vy');
$vb = getLatestValue($conn, 'Vb');

$ir = getLatestValue($conn, 'Ir');
$iy = getLatestValue($conn, 'Iy');
$ib = getLatestValue($conn, 'Ib');

$kw = getLatestValue($conn, 'KW-Tot.');

$ebkwh = getLatestValue($conn, 'EB-KWH');
$dgkwh = getLatestValue($conn, 'DG-KWH');

$openIncidents = $conn->query("
SELECT COUNT(*)
FROM incidents
WHERE status='OPEN'
")->fetchColumn();

$activeAlarms = $conn->prepare("
    SELECT COUNT(*)
    FROM alarms
    WHERE status='ACTIVE' AND meter_id = ?
");
$activeAlarms->execute([$meter_id]);
$activeAlarms = $activeAlarms->fetchColumn();

$availability = $conn->query("
SELECT ROUND(AVG(availability_percent),2)
FROM site_availability
")->fetchColumn();

$mttr = $conn->query("
SELECT ROUND(
AVG(
TIMESTAMPDIFF(
MINUTE,
opened_at,
resolved_at
)
),2)
FROM incidents
WHERE resolved_at IS NOT NULL
")->fetchColumn();

$meterCount = $conn->query("
    SELECT COUNT(*) AS cnt
    FROM meter_master
")->fetch(PDO::FETCH_ASSOC);

$meter_id = isset($_GET['meter_id'])
    ? (int)$_GET['meter_id']
    : 1;

// Client isolation: never trust meter_id from the URL without checking ownership
if (!meter_belongs_to_user($conn, $meter_id))
{
    if (is_admin())
    {
        $meter_id = 1;
    }
    else
    {
        $fallback = $conn->prepare("
            SELECT meter_id FROM meter_master
            WHERE company = ?
            ORDER BY meter_id LIMIT 1
        ");
        $fallback->execute([user_company()]);
        $meter_id = (int) ($fallback->fetchColumn() ?: 0);
    }
}

// Critical / Warning active alarm counts, scoped to the selected meter
// (never system-wide — a client should never see another company's alarm counts)
$critical = $conn->prepare("
    SELECT COUNT(*) FROM alarms
    WHERE status='ACTIVE' AND severity='CRITICAL' AND meter_id = ?
");
$critical->execute([$meter_id]);
$critical = $critical->fetchColumn();

$warning = $conn->prepare("
    SELECT COUNT(*) FROM alarms
    WHERE status='ACTIVE' AND severity='WARNING' AND meter_id = ?
");
$warning->execute([$meter_id]);
$warning = $warning->fetchColumn();

$stmt = $conn->prepare("
SELECT *
FROM parameter_master_princek2
WHERE displayindashboard = 1
AND meter_group_id = ?
AND priority IS NOT NULL
ORDER BY priority
LIMIT 12
");
$stmt->execute([$meter_id]);

/*
 | Consumption profile — EB/DG are cumulative counters, so
 | consumption over a period is MAX(value) - MIN(value) within it.
*/
function consumption_for(PDO $conn, $meter_id, $from, $to)
{
    $stmt = $conn->prepare("
        SELECT
            MAX(CASE WHEN parameter_name = 'EB-KWH' THEN value END)
            - MIN(CASE WHEN parameter_name = 'EB-KWH' THEN value END) AS eb,
            MAX(CASE WHEN parameter_name = 'DG-KWH' THEN value END)
            - MIN(CASE WHEN parameter_name = 'DG-KWH' THEN value END) AS dg
        FROM meter_readings
        WHERE meter_id = ?
        AND DATE(reading_time) BETWEEN ? AND ?
    ");
    $stmt->execute([$meter_id, $from, $to]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return [
        'eb' => $row['eb'] ?? 0,
        'dg' => $row['dg'] ?? 0,
    ];
}

$todayDate      = date('Y-m-d');
$yesterdayDate  = date('Y-m-d', strtotime('-1 day'));
$thisMonthStart = date('Y-m-01');
$lastMonthStart = date('Y-m-01', strtotime('first day of last month'));
$lastMonthEnd   = date('Y-m-t', strtotime('first day of last month'));

$today     = consumption_for($conn, $meter_id, $todayDate, $todayDate);
$yesterday = consumption_for($conn, $meter_id, $yesterdayDate, $yesterdayDate);
$thisMonth = consumption_for($conn, $meter_id, $thisMonthStart, $todayDate);
$lastMonth = consumption_for($conn, $meter_id, $lastMonthStart, $lastMonthEnd);

/*
 | Live / offline meter status — a meter counts as "live" if it has
 | reported a reading in the last 5 minutes.
*/
$liveStmt = $conn->query("
    SELECT COUNT(DISTINCT meter_id) AS live_count
    FROM meter_readings
    WHERE reading_time >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
");
$liveCount = $liveStmt->fetch(PDO::FETCH_ASSOC)['live_count'];

$totalStmt = $conn->query("
    SELECT COUNT(*) AS total_meters
    FROM meter_master
");
$totalMeters = $totalStmt->fetch(PDO::FETCH_ASSOC)['total_meters'];

$offlineCount = $totalMeters - $liveCount;

$lastStmt = $conn->query("
    SELECT MAX(reading_time) AS last_connected
    FROM meter_readings
");
$lastConnected = $lastStmt->fetch(PDO::FETCH_ASSOC)['last_connected'];

// Minutes since the most recent reading from ANY meter, for the ONLINE/OFFLINE badge
$minutesSinceLastReading = $lastConnected
    ? (time() - strtotime($lastConnected)) / 60
    : null;

include 'includes/header.php';
include 'includes/sidebar.php';

?>

<div class="content">

<div class="row mb-4">

    <div class="col-md-3">
        <div class="card bg-danger text-white p-3">
            <h5>🚨 Critical Alarms</h5>
            <h2><?= $critical ?></h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card bg-warning text-dark p-3">
            <h5>⚠ Warning Alarms</h5>
            <h2><?= $warning ?></h2>
        </div>
    </div>



    <div class="col-md-3">
        <div class="card bg-success text-white shadow">
            <div class="card-body">
                <h5>🟢 Site Availability</h5>
                <h2><?= $availability ?: 0 ?>%</h2>
            </div>
        </div>
    </div>
</div>

    
   <div class="top-header">

    <div>

    <h2>⚡ Energy Dashboard</h2>

        <form method="get" class="mt-2">

    <select
        name="meter_id"
        class="form-select"
        onchange="this.form.submit()">

        <?php

        // Client isolation: only list meters the logged-in user is allowed to see
        if (is_admin())
        {
            $meters = $conn->query("
                SELECT meter_id,meter_name
                FROM meter_master
                ORDER BY meter_id
            ");
        }
        else
        {
            $metersStmt = $conn->prepare("
                SELECT meter_id,meter_name
                FROM meter_master
                WHERE company = ?
                ORDER BY meter_id
            ");
            $metersStmt->execute([user_company()]);
            $meters = $metersStmt;
        }

        foreach($meters as $meter)
        {
        ?>

        <option
            value="<?= $meter['meter_id']; ?>"
            <?= $meter_id == $meter['meter_id'] ? 'selected' : ''; ?>>

            <?= $meter['meter_name']; ?>

        </option>

        <?php } ?>

    </select>

</form>

        <div>
            Welcome,
            <?= $_SESSION['user']; ?>
        </div>

        <div id="clock"></div>

    </div>

   <div>

    <button
        class="btn btn-dark me-2"
        onclick="toggleTheme()">
        Dark Mode
    </button>

   <a
    href="export_excel.php?meter_id=<?= $meter_id; ?>"
    class="btn btn-success me-2">
    Export Excel
</a>

    <a
        href="export_pdf.php?meter_id=<?= $meter_id; ?>"
        class="btn btn-info me-2">
        Export PDF
    </a>

    <a
        href="logout.php"
        class="btn btn-danger">
        Logout
    </a>

</div>


</div>

<div class="row mb-4">

     <div class="col-md-3">

    <div class="card bg-info text-white">

        <div class="card-body">

            <h6>Total Meters</h6>

            <h3 id="meterCount">
    <?= $meterCount['cnt']; ?>
</h3>

        </div>

    </div>

</div>

    <div class="col-md-3">

        <div class="card bg-success text-white">

            <div class="card-body">

                <h6>Total EB Energy</h6>

                <h3 id="ebTotal">0</h3>

            </div>

        </div>

    </div>

    <div class="col-md-3">

        <div class="card bg-warning text-dark">

            <div class="card-body">

                <h6>Total DG Energy</h6>

                <h3 id="dgTotal">0</h3>

            </div>

        </div>

    </div>

    <div class="col-md-3">

        <div class="card bg-danger text-white">

            <div class="card-body">

                <h6>Active Alarms</h6>

                <h3 id="alarmSummary">0</h3>

            </div>

        </div>

    </div>

</div>

    <div class="row">

        <?php foreach($stmt as $row){ ?>

        <div class="col-md-3 mb-3">

            <div class="card shadow">

                <div class="card-body">

                    <div>
                        <?= $row['parameter_name']; ?>
                    </div>

                    <div
                        class="metric-value"
                        id="p<?= preg_replace('/[^A-Za-z0-9]/','',$row['parameter_name']); ?>">
                        0
                    </div>

                </div>

            </div>

        </div>

        <?php } ?>

    </div>

    <div class="card mt-3">

    <div class="card-header bg-primary text-white">
        Consumption Profile
    </div>

     <table class="table table-bordered">

        <thead>

        <tr>
            <th>Period</th>
            <th>Cons. EB</th>
            <th>Cons. DG</th>
        </tr>

        </thead>

        <tbody>

        <tr>
            <td>Today</td>
            <td><?= number_format($today['eb'],2) ?></td>
            <td><?= number_format($today['dg'],2) ?></td>
        </tr>

        <tr>
            <td>Yesterday</td>
            <td><?= number_format($yesterday['eb'],2) ?></td>
            <td><?= number_format($yesterday['dg'],2) ?></td>
        </tr>

        <tr>
            <td>This Month</td>
            <td><?= number_format($thisMonth['eb'],2) ?></td>
            <td><?= number_format($thisMonth['dg'],2) ?></td>
        </tr>

        <tr>
            <td>Last Month</td>
            <td><?= number_format($lastMonth['eb'],2) ?></td>
            <td><?= number_format($lastMonth['dg'],2) ?></td>
        </tr>

        </tbody>

    </table>

</div>

<div class="row">

    <div class="col-md-3">
        <div class="card p-3">
            <h5>Voltage</h5>
            <h2 id="voltage">--</h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card p-3">
            <h5>Current</h5>
            <h2 id="current">--</h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card p-3">
            <h5>Power</h5>
            <h2 id="power">--</h2>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card p-3">
            <h5>kWh</h5>
            <h2 id="kwh">--</h2>
        </div>
    </div>

</div>

    <!-- KW Trend -->

    <div class="card shadow mb-4">

        <div class="card-body">

            <h5>📈 KW Trend</h5>

            <canvas id="kwChart" height="100"></canvas>

        </div>

    </div>

    <!-- Voltage Trend -->

    <div class="card shadow mb-4">

        <div class="card-body">

            <h5>⚡ Voltage Trend (Vr / Vy / Vb)</h5>

            <canvas id="voltageChart"></canvas>

        </div>

    </div>

    <!-- Current Trend -->

    <div class="card shadow mb-4">

        <div class="card-body">

            <h5>🔌 Current Trend (Ir / Iy / Ib)</h5>

            <canvas id="currentChart"></canvas>

        </div>

    </div>

 <div class="row mb-4">

        <div class="col-md-4">
        <h5>📊 EB vs DG Energy</h5>

        <div style="width:300px; height:300px; margin:auto;">
            <canvas id="pieChart"></canvas>
        </div>
        
    </div>


     <div class="col-md-4">         
         <h5>🎫 Open Incidents</h5>
         <h2><?= $openIncidents ?></h2>
        
    </div>


    <div class="col-md-4">
        <div class="card bg-primary text-white shadow">
            <div class="card-body">
                <h5>⏱ MTTR</h5>
                <h2><?= $mttr ?: 0 ?> Min</h2>
            </div>
        </div>
    </div>
</div>

    <!-- Meter connectivity status -->

    <div class="row mb-4">

        <div class="col-md-4">
            <div class="card bg-success text-white p-3">
                <h5>🟢 Live Meters</h5>
                <h2><?= $liveCount; ?></h2>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card bg-danger text-white p-3">
                <h5>🔴 Offline Meters</h5>
                <h2><?= $offlineCount; ?></h2>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card bg-info text-white p-3">
                <h5>🕒 Last Connected</h5>
                <h6><?= $lastConnected; ?></h6>

                <?php if ($minutesSinceLastReading !== null && $minutesSinceLastReading <= 5): ?>
                    <span class="badge bg-success">ONLINE</span>
                <?php else: ?>
                    <span class="badge bg-danger">OFFLINE</span>
                <?php endif; ?>

            </div>
        </div>

    </div>

    

<!-- Live KPI Values -->

<script>

function toggleTheme()
{
    document.body.classList.toggle('dark');
}

function loadData()
{
    fetch('api/getLiveData.php?meter_id=<?=$meter_id;?>')

    .then(response => response.json())
    .then(data => {

        let vSum = 0, vCount = 0;
        let iSum = 0, iCount = 0;

        data.forEach(item => {

            let key = item.parameter_name
                .replace(/ /g,'')
                .replace(/\./g,'')
                .replace(/-/g,'');

            let box =
            document.getElementById('p' + key);

            if(box)
            {
                box.innerHTML = item.value;
            }

            // Feed the Voltage / Current / Power / kWh summary cards
            if(['Vr','Vy','Vb'].includes(item.parameter_name))
            {
                vSum += parseFloat(item.value);
                vCount++;
            }

            if(['Ir','Iy','Ib'].includes(item.parameter_name))
            {
                iSum += parseFloat(item.value);
                iCount++;
            }

            if(item.parameter_name === 'KW-Tot.')
            {
                document.getElementById('power').innerHTML = item.value;
            }

            if(item.parameter_name === 'EB-KWH')
            {
                document.getElementById('kwh').innerHTML = item.value;
            }

        });

        if(vCount > 0)
        {
            document.getElementById('voltage').innerHTML =
                (vSum / vCount).toFixed(1);
        }

        if(iCount > 0)
        {
            document.getElementById('current').innerHTML =
                (iSum / iCount).toFixed(1);
        }

    });
}

loadData();
setInterval(loadData,5000);

</script>

<div class="alert alert-info">
    Last Updated: <?= date('d-m-Y H:i:s'); ?>
</div>

<div class="badge bg-success">

    ● Live

</div>

<!-- KW Trend -->

<script>

let kwChart = new Chart(
document.getElementById('kwChart'),
{
    type:'line',

    data:{
        labels:[],
        datasets:[{
            label:'KW-Tot.',
            data:[],
            borderColor:'blue',
            backgroundColor:'rgba(0,0,255,0.2)',
            fill:true,
            tension:0.4
        }]
    }
});

function loadKwTrend()
{
    fetch('api/kwdata.php?meter_id=<?=$meter_id;?>')

    .then(response => response.json())
    .then(data => {

        kwChart.data.labels =
            data.map(row => row.id);

        kwChart.data.datasets[0].data =
            data.map(row => Number(row.value));

        kwChart.update();
    });
}

loadKwTrend();
setInterval(loadKwTrend,5000);

</script>

<!-- Voltage Chart -->

<script>

fetch('api/voltagedata.php?meter_id=<?=$meter_id;?>')
.then(response => response.json())
.then(data => {

    new Chart(
        document.getElementById('voltageChart'),
        {
            type:'line',

            data:{

                labels:[
                    '1','2','3','4','5',
                    '6','7','8','9','10'
                ],

                datasets:[

                {
                    label:'Vr',
                    data:data.Vr,
                    borderColor:'red'
                },

                {
                    label:'Vy',
                    data:data.Vy,
                    borderColor:'blue'
                },

                {
                    label:'Vb',
                    data:data.Vb,
                    borderColor:'green'
                }

                ]
            }
        }
    );

});

</script>

<!-- Current Chart -->

<script>

fetch('api/currentdata.php?meter_id=<?=$meter_id;?>')
.then(response => response.json())
.then(data => {

    new Chart(
        document.getElementById('currentChart'),
        {
            type:'line',

            data:{

                labels:[
                    '1','2','3','4','5'
                ],

                datasets:[

                {
                    label:'Ir',
                    data:data.Ir,
                    borderColor:'red'
                },

                {
                    label:'Iy',
                    data:data.Iy,
                    borderColor:'blue'
                },

                {
                    label:'Ib',
                    data:data.Ib,
                    borderColor:'green'
                }

                ]
            }
        }
    );

});

</script>

<!-- Pie Chart -->

<script>

fetch('api/piedata.php?meter_id=<?=$meter_id;?>')
.then(response => response.json())
.then(data => {

    console.log("PIE DATA:", data);

    document.getElementById('ebTotal').innerHTML =
        data.eb;

    document.getElementById('dgTotal').innerHTML =
        data.dg;

    const ctx = document.getElementById('pieChart');

    new Chart(ctx, {
        type: 'pie',

        data: {
            labels: [
                'EB Energy',
                'DG Energy'
            ],

            datasets: [{
                data: [
                    parseFloat(data.eb),
                    parseFloat(data.dg)
                ],

                backgroundColor: [
                    '#28a745',
                    '#fd7e14'
                ]
            }]
        },

        options: {
            responsive: true
        }

    });

})
.catch(error => console.error(error));

</script>


<!-- Alarm Panel -->

<div class="col-md-3">
    <div class="card bg-danger text-white shadow">
        <div class="card-body">
            <h5>🚨 Active Alarms</h5>
            <h2><?= $activeAlarms; ?></h2>
        </div>
    </div>
</div>

<script>

function ackAlarm(id)
{
    fetch('api/ack_alarm.php',
    {
        method:'POST',

        headers:{
            'Content-Type':
            'application/x-www-form-urlencoded'
        },

        body:'id=' + id
    })
    .then(response => response.text())
    .then(result => {

        loadAlarms();

    });
}

function loadAlarms()
{
    fetch('api/alarmdata.php?meter_id=<?=$meter_id;?>')
    .then(response => response.json())
    .then(data => {

        document.getElementById('alarmSummary').innerHTML =
            data.length;

        let html = '';

        if(data.length === 0)
        {
            html =
                '<div class="text-muted">No active alarms.</div>';

            document.title = '⚡ Energy Dashboard';
        }
        else
        {
            let latestAlarm = data[0];

            if(!sessionStorage.getItem('alarmShown'))
            {
                alert(
                    "⚠ Alarm Detected\n\n" +
                    "Parameter: " + latestAlarm.parameter_name +
                    "\nActual Value: " + latestAlarm.actual_value +
                    "\nLimit: " + latestAlarm.alarm_value
                );

                sessionStorage.setItem('alarmShown','1');
            }

            document.title =
                "🚨 " + data.length + " Active Alarms";
        }

        data.forEach(alarm => {

            html += `
            <div class="alert alert-danger">

                <strong>${alarm.parameter_name}</strong>

                | Limit: ${alarm.alarm_value}

                | Actual: ${alarm.actual_value}

                <button
                    class="btn btn-sm btn-light float-end"
                    onclick="ackAlarm(${alarm.id})">

                    Acknowledge

                </button>

            </div>
            `;

        });

        document.getElementById('alarmCount').innerHTML =
            data.length;

        document.getElementById('alarmContainer').innerHTML =
            html;

    });
}

loadAlarms();

setInterval(loadAlarms,5000);

</script>

<script>

function updateClock()
{
    let now = new Date();

    document.getElementById("clock").innerHTML =
        now.toLocaleDateString() +
        " " +
        now.toLocaleTimeString();
}

updateClock();

setInterval(updateClock, 1000);

</script>

<script>

setInterval(function() {

    location.reload();

}, 50000);

</script>

<?php include 'includes/footer.php'; ?>
