<?php

function logEvent($conn, $username, $activity)
{
    $stmt = $conn->prepare("
        INSERT INTO event_log
        (username, activity)
        VALUES (?, ?)
    ");

    $stmt->execute([
        $username,
        $activity
    ]);
}
