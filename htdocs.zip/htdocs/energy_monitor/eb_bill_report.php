<?php

session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

require 'config/db.php';

$company = $_GET['company'] ?? '';
$type    = $_GET['type'] ?? '';

$sql = "SELECT * FROM bill_master WHERE 1=1";
$params = [];

if($company != '')
{
    $sql .= " AND company = ?";
    $params[] = $company;
}

if($type != '')
{
    $sql .= " AND bill_type = ?";
    $params[] = $type;
}

$sql .= " ORDER BY bill_month DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);

include 'includes/header.php';
include 'includes/sidebar.php';

?>

<div class="content">

<h2>💰 EB Bill Report</h2>

<form method="get" class="row mb-3">

    <div class="col-md-3">
        <label>Bill Type</label>
        <select name="type" class="form-control">
            <option value="">All</option>
            <option value="BECIL">BECIL</option>
            <option value="NON_BECIL">NON BECIL</option>
        </select>
    </div>

    <div class="col-md-3">
        <label>Company</label>
        <select name="company" class="form-control">
            <option value="">All</option>
            <option value="KAL">KAL</option>
            <option value="SAFL">SAFL</option>
        </select>
    </div>

    <div class="col-md-2">
        <label>&nbsp;</label>
        <button class="btn btn-primary form-control">
            Search
        </button>
    </div>

</form>

<table class="table table-bordered table-striped">

<thead>
<tr>
    <th>Bill Type</th>
    <th>Company</th>
    <th>State</th>
    <th>Branch</th>
    <th>Broadcaster</th>
    <th>Month</th>
    <th>EB Units</th>
    <th>Cost</th>
    <th>Transmitter</th>
</tr>
</thead>

<tbody>

<?php foreach($stmt as $row){ ?>

<tr>

    <td><?= $row['bill_type']; ?></td>

    <td><?= $row['company']; ?></td>

    <td><?= $row['state_name']; ?></td>

    <td><?= $row['branch_name']; ?></td>

    <td><?= $row['broadcaster']; ?></td>

    <td><?= date('M-Y', strtotime($row['bill_month'])); ?></td>

    <td><?= number_format($row['eb_units'],2); ?></td>

    <td><?= number_format($row['amount'],2); ?></td>

    <td><?= $row['transmitter']; ?></td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

<?php include 'includes/footer.php'; ?>