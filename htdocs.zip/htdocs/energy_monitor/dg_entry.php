<?php

session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

require 'config/db.php';
$company = $_GET['company'] ?? '';

$msg = '';

if(isset($_POST['save']))
{
    $seconds =
        strtotime($_POST['power_in']) -
        strtotime($_POST['power_out']);

    $hours = floor($seconds / 3600);

    $minutes = floor(($seconds % 3600) / 60);

    $runtime = $_POST['runtime'];

    $stmt = $conn->prepare("
    INSERT INTO dg_bills
    (
        company,
        state_name,
        branch_name,
        dg_capacity,
        office_location,
        cti_location,
        entry_date,
        power_out,
        power_in,
        runtime,
        unit_generation,
        fuel_consumption,
        remarks
    )
    VALUES
    (
        ?,?,?,?,?,?,?,?,?,?,?,?,?
    )
    ");

    $stmt->execute([
        $company,
        $_POST['state_name'],
        $_POST['branch_name'],
        $_POST['dg_capacity'],
        $_POST['office_location'],
        $_POST['cti_location'],
        $_POST['entry_date'],
        $_POST['power_out'],
        $_POST['power_in'],
        $runtime,
        $_POST['unit_generation'],
        $_POST['fuel_consumption'],
        $_POST['remarks']
    ]);

    $msg = "DG Entry Saved Successfully";
}

include 'includes/header.php';
include 'includes/sidebar.php';

?>

<div class="content">

<h2>⚡ DG Entry</h2>

<div class="alert alert-info">
    Company: <strong><?= $company ?></strong>
</div>

<?php if($msg){ ?>
<div class="alert alert-success">
    <?= $msg ?>
</div>
<?php } ?>
<form method="post">

    
    <div class="mb-3">
        <label>State</label>
        <input type="text" name="state_name" class="form-control">
    </div>

    <div class="mb-3">
        <label>Branch</label>
        <input type="text" name="branch_name" class="form-control">
    </div>

    <div class="mb-3">
        <label>DG Capacity</label>
        <input type="text" name="dg_capacity" class="form-control">
    </div>

    <div class="mb-3">
        <label>Office Location</label>
        <input type="text" name="office_location" class="form-control">
    </div>

    <div class="mb-3">
        <label>CTI Location</label>
        <input type="text" name="cti_location" class="form-control">
    </div>

    <div class="mb-3">
        <label>Date</label>
        <input type="date" name="entry_date" class="form-control">
    </div>

   <div class="mb-3">
    <label>Power Out</label>
    <input type="time"
           name="power_out"
           class="form-control">
</div>

<div class="mb-3">
    <label>Power In</label>
    <input type="time"
           name="power_in"
           class="form-control">
</div>

<div class="mb-3">
    <label>Runtime</label>
    <input type="text"
           id="runtime"
           class="form-control"
           readonly>
</div>

    <div class="mb-3">
        <label>Unit Generation</label>
        <input type="number" step="0.01" name="unit_generation" class="form-control">
    </div>

    <div class="mb-3">
        <label>Fuel Consumption</label>
        <input type="number" step="0.01" name="fuel_consumption" class="form-control">
    </div>

    <div class="mb-3">
        <label>Remarks</label>
        <textarea name="remarks" class="form-control"></textarea>
    </div>

    <button type="submit" name="save" class="btn btn-primary">
        Save DG Entry
    </button>

</form>

</div>
<script>

function calculateRuntime()
{
    let outTime = document.getElementsByName('power_out')[0].value;
    let inTime  = document.getElementsByName('power_in')[0].value;

    if(outTime && inTime)
    {
        let start = new Date("2000-01-01 " + outTime);
        let end   = new Date("2000-01-01 " + inTime);

        let diff = (end - start) / 1000;

        if(diff < 0)
        {
            diff += 24 * 3600;
        }

        let hours = Math.floor(diff / 3600);
        let minutes = Math.floor((diff % 3600) / 60);

        let runtimeText =
            hours + " Hr " + minutes + " Min";

        document.getElementById('runtime').value = runtimeText;
        document.getElementById('runtime_hidden').value = runtimeText;
    }
}

document.getElementsByName('power_out')[0]
        .addEventListener('change', calculateRuntime);

document.getElementsByName('power_in')[0]
        .addEventListener('change', calculateRuntime);

</script>
<?php include 'includes/footer.php'; ?>