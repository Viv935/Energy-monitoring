<?php

session_start();

if(!isset($_SESSION['user']))
{
    header("Location: login.php");
    exit;
}

require 'config/db.php';

$stmt = $conn->query("
    SELECT
        id,
        parameter_name,
        actual_value,
        alarm_value,
        status
    FROM alarms
    ORDER BY id DESC
");

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<div class="content">

    <h2>📜 Alarm History</h2>

    <table class="table table-bordered table-striped">

        <thead>

            <tr>
                <th>ID</th>
                <th>Parameter</th>
                <th>Actual Value</th>
                <th>Limit</th>
                <th>Status</th>
            </tr>

        </thead>

        <tbody>

        <?php foreach($stmt as $row){ ?>

            <tr>

                <td><?= $row['id']; ?></td>

                <td><?= $row['parameter_name']; ?></td>

                <td><?= $row['actual_value']; ?></td>

                <td><?= $row['alarm_value']; ?></td>

                <td><?= $row['status']; ?></td>

            </tr>

        <?php } ?>

        </tbody>

    </table>

</div>

<?php include 'includes/footer.php'; ?>