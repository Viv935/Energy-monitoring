<?php

session_start();

if(!isset($_SESSION['user']))
{
    header("Location: login.php");
    exit;
}

require 'config/db.php';

$stmt = $conn->query("
SELECT *
FROM alarms
WHERE status = 'ACTIVE'
ORDER BY alarm_time DESC
");

include 'includes/header.php';
include 'includes/sidebar.php';

?>

<div class="content">

<h2 class="text-danger">
🚨 Alarm Dashboard
</h2>

<table class="table table-bordered table-striped">

<thead>

<tr>

<th>ID</th>
<th>Parameter</th>
<th>Limit</th>
<th>Actual</th>
<th>Status</th>
<th>Time</th>
<th>Action</th>

</tr>

</thead>

<tbody>

<?php foreach($stmt as $row){ ?>

<tr>

<td><?= $row['id'] ?></td>

<td><?= $row['parameter_name'] ?></td>

<td><?= $row['alarm_value'] ?></td>

<td><?= $row['actual_value'] ?></td>

<td>

<span class="badge bg-danger">ACTIVE</span>

</td>

<td><?= $row['alarm_time'] ?></td>

<td>

<button
    class="btn btn-sm btn-light"
    onclick="ackAlarm(<?= $row['id'] ?>)">
    Acknowledge
</button>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

<script>

function ackAlarm(id)
{
    fetch('api/ack_alarm.php',
    {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'id=' + id
    })
    .then(response => response.text())
    .then(result => {
        location.reload();
    });
}

</script>

<?php include 'includes/footer.php'; ?>