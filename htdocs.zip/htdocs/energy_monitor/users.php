<?php

session_start();

if(!isset($_SESSION['user']))
{
    header("Location: login.php");
    exit;
}

require 'config/db.php';

$users = $conn->query("
SELECT id, username
FROM users
ORDER BY username
");

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<div class="content">

    <h2>👤 User Management</h2>

    <table class="table table-bordered">

        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
            </tr>
        </thead>

        <tbody>

        <?php foreach($users as $user){ ?>

            <tr>
                <td><?= $user['id']; ?></td>
                <td><?= $user['username']; ?></td>
            </tr>

        <?php } ?>

        </tbody>

    </table>

</div>

<?php include 'includes/footer.php'; ?>