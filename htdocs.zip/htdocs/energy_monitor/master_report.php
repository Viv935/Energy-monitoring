<?php

session_start();

if(!isset($_SESSION['user']))
{
    header("Location: login.php");
    exit;
}

require 'config/db.php';

$totalBill = $conn->query("
    SELECT
        SUM(amount) total_cost,
        SUM(eb_units) total_units
    FROM bill_master
")->fetch();

$companyData = $conn->query("
    SELECT
        company,
        SUM(amount) total_cost
    FROM bill_master
    GROUP BY company
");

$companies = [];
$costs = [];

foreach($companyData as $row)
{
    $companies[] = $row['company'];
    $costs[] = $row['total_cost'];
}

$typeData = $conn->query("
    SELECT
        bill_type,
        SUM(amount) total_cost
    FROM bill_master
    GROUP BY bill_type
");

$types = [];
$typeCosts = [];

foreach($typeData as $row)
{
    $types[] = $row['bill_type'];
    $typeCosts[] = $row['total_cost'];
}

/*
 | TODO: this query is fetched but nothing renders it yet.
 | Was this meant to be a third chart (units per state)?
 | Left the query here but not wired to any output until confirmed.
*/
$stateData = $conn->query("
    SELECT
        state_name,
        SUM(eb_units) units
    FROM bill_master
    GROUP BY state_name
")->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
include 'includes/sidebar.php';

?>

<div class="content">

<h2>📈 Management Dashboard</h2>

<div class="row">

    <div class="col-md-3">
        <div class="card bg-primary text-white p-3">
            <h5>Total Cost</h5>
            <h3>
                ₹ <?= number_format($totalBill['total_cost'],0) ?>
            </h3>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card bg-success text-white p-3">
            <h5>Total Units</h5>
            <h3>
                <?= number_format($totalBill['total_units'],0) ?>
            </h3>
        </div>
    </div>

</div>

<br>

<div class="row">

    <div class="col-md-6">

        <div class="card p-3">

            <h5>KAL vs SAFL Cost</h5>

            <canvas id="companyChart"></canvas>

        </div>

    </div>

    <div class="col-md-6">
        <div class="card p-3">
            <h5>BECIL vs NON-BECIL</h5>
            <canvas id="typeChart"></canvas>
        </div>
    </div>

</div>

</div>

<script>

const ctx = document.getElementById('companyChart');

new Chart(ctx, {
    type: 'pie',
    data: {
        labels: <?= json_encode($companies); ?>,
        datasets: [{
            label: 'Cost',
            data: <?= json_encode($costs); ?>,
            backgroundColor: [
                '#0d6efd',
                '#198754',
                '#ffc107',
                '#dc3545'
            ]
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});

new Chart(
document.getElementById('typeChart'),
{
    type: 'doughnut',
    data: {
        labels: <?= json_encode($types); ?>,
        datasets: [{
            data: <?= json_encode($typeCosts); ?>
        }]
    }
});

</script>

<?php include 'includes/footer.php'; ?>