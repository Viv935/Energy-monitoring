<?php

session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

require 'config/db.php';

$company = $_GET['company'] ?? '';
$from    = $_GET['from'] ?? '';
$to      = $_GET['to'] ?? '';
$branch  = $_GET['branch'] ?? '';

$sql = "SELECT * FROM dg_bills WHERE 1=1";
$params = [];

if ($company != '') {
    $sql .= " AND company = ?";
    $params[] = $company;
}

if ($branch != '') {
    $sql .= " AND branch_name = ?";
    $params[] = $branch;
}

if ($from != '') {
    $sql .= " AND entry_date >= ?";
    $params[] = $from;
}

if ($to != '') {
    $sql .= " AND entry_date <= ?";
    $params[] = $to;
}

$sql .= " ORDER BY entry_date DESC, id DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);

include 'includes/header.php';
include 'includes/sidebar.php';

?>

<div class="content">

<h2>⚡ DG Report</h2>

<form method="get" class="row mb-3">

    <div class="col-md-2">
        <label>Company</label>
        <select name="company" class="form-control">
            <option value="">All</option>
            <option value="KAL" <?= $company=='KAL'?'selected':'' ?>>
                KAL
            </option>
            <option value="SAFL" <?= $company=='SAFL'?'selected':'' ?>>
                SAFL
            </option>
        </select>
    </div>

    <div class="col-md-3">
        <label>Branch</label>
        <input type="text"
               name="branch"
               value="<?= $branch ?>"
               class="form-control">
    </div>

    <div class="col-md-2">
        <label>From Date</label>
        <input type="date"
               name="from"
               value="<?= $from ?>"
               class="form-control">
    </div>

    <div class="col-md-2">
        <label>To Date</label>
        <input type="date"
               name="to"
               value="<?= $to ?>"
               class="form-control">
    </div>

    <div class="col-md-2">
        <label>&nbsp;</label>
        <button type="submit"
                class="btn btn-primary form-control">
            Search
        </button>
    </div>

</form>

<table class="table table-bordered table-striped">

<thead>
<tr>
    <th>Date</th>
    <th>Company</th>
    <th>State</th>
    <th>Branch</th>
    <th>DG Capacity</th>
    <th>Power Out</th>
    <th>Power In</th>
    <th>Runtime</th>
    <th>Units Generated</th>
    <th>Fuel Consumption</th>
</tr>
</thead>

<tbody>

<?php foreach($stmt as $row){ ?>

<tr>

    <td><?= $row['entry_date']; ?></td>
    <td><?= $row['company']; ?></td>
    <td><?= $row['state_name']; ?></td>
    <td><?= $row['branch_name']; ?></td>
    <td><?= $row['dg_capacity']; ?></td>
    <td><?= $row['power_out']; ?></td>
    <td><?= $row['power_in']; ?></td>
    <td><?= $row['runtime']; ?></td>
    <td><?= $row['unit_generation']; ?></td>
    <td><?= $row['fuel_consumption']; ?></td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

<?php include 'includes/footer.php'; ?>